//clase main
package Inicio;


public class Iniciar {
    
    public static void main(String[] args) {
        Juego iniciar = new Juego();
        iniciar.iniciarJuego();
    }
}
