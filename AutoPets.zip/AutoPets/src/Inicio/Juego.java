
package Inicio;
import java.util.Scanner;

public class Juego {
    
    private Scanner scanner=new Scanner(System.in);
    
    public void iniciarJuego() {
        
        String opcion = "";
        int eleccion=-1;
        
        while (eleccion!=6){
            System.out.println("\n\n\n\nUsuario seleccione la opción\n");
            System.out.println("1) Informacion sobre Modos de Juego");
            System.out.println("2) Modo Arena");
            System.out.println("3) Modo Versus ");
            System.out.println("4) Modo Creativo ");
            System.out.println("5) Salir");
            System.out.print("\n ¿Opción? ");
        
            opcion = scanner.nextLine();
            if (!opcion.equals("")) eleccion=Integer.parseInt(opcion);
        
            switch(eleccion){
                case 1:
                    System.out.println("Lucha contra otros jugadores a tu propio ritmo en este juego de batallas automático gratuito.\n" +
                    "En Super Auto Pets, construyes un equipo a partir de un adorable elenco de animales que lucharán por ti.\n" +
                    "Cada uno tiene habilidades únicas, ¡así que elige sabiamente quién se unirá a tu equipo!\n\n"+
                    "************Modo Arena:************\n"
                    +"En el modo arena, jugarás contra el propo juego, *UN BOT* (Los equipos enemigos son  aleatorios, ambos tienen 10 vidas \n"
                    + "también podrás comprar por turnos mascotas que se presentarán de manera aleatoria en una tienda a lo largo de las rondas\n" +
                            "recuerda evolucionar tus mascotas\n\n"+
                    "************Modo Versus:************\n"+
                    "En el modo versus se siguen las mismas reglas del modo arena, excepto que: te enfrentarse a otro jugador, cada uno elige, ordena y fusiona sus mscotas por turnos\n\n\n"+
                    "**********************para mas detalles consulta el manual de usuario**********************\n\n"+
                            "**********Modo Creativo**********\n"+"en desarrollo");
                    break;
                case 2:
                    Arena arena= new Arena();
                    break;
                case 3:
                    Versus versus= new Versus();;
                    break;
                case 4:
                    System.out.println("En desarrollo...");
                    iniciarJuego();
                    break;
                case 5:
                    System.exit(0);
                    eleccion=6;
                    break;
                default:
                    break;
            }
        
        }    
        
    }
}
