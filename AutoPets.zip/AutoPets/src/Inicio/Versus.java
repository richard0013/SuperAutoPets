
package Inicio;

import CamposJuego.*;
import Otros.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Versus {
    private Jugador[] partida = new Jugador[2];
    private int ronda;
    private Campos terreno;

    public Versus() {
        ronda=1;
        IniciarPartica();
    }
    
    public void IniciarPartica(){
        partida[0]= new Jugador();
        partida[1]= new Jugador();
        for (int i = 0; i < 2; i++) {
            partida[i].setNombre(IngresoTexto.Leer("\n\n\nIngrese nombre para el Jugador No. "+(i+1)));
            MenuTurno nuevaCompra=new MenuTurno(partida[i], 1);
            partida[i]=nuevaCompra.getComprador();
        }
        elegirCampo();
    }
    
    public void elegirCampo(){
        int opcion;
        String respuesta=IngresoTexto.Leer("\n\nEliga Mapa para Jugar \nOpcion 1: Pantano \nOpcion 2: Nubes"
                + "\nOpcion 3: Mar \nOpcion 4: Bosque \nOpcion 5: Granja"
                +"\nOpcion 6: Sin Campo \nOpcion 7: Sabana \nEliga la opcion del mapa en el que desea jugar");
        opcion=Integer.parseInt(respuesta);
        switch(opcion){
            case 1: 
                batallaEquipos("pantano");
                break;
            case 2: 
                batallaEquipos("nubes");
                break;
            case 3: 
                batallaEquipos("Mar");
                break;
            case 4: 
                batallaEquipos("Bosque");
                break;
            case 5: 
                batallaEquipos("Granja");
                break;
            case 6: 
                batallaEquipos("Sin Campo");
                break;
            case 7: 
                batallaEquipos("Sabana");
                break;
            default : 
                elegirCampo();
                break;
        }
    }
    
    public void batallaEquipos(String CampoElegido){
        int ganadosjug1=0;
        int ganadosjug2=0;
        Batalla batRonda= null;
        DateTimeFormatter fecha = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        EscribirArchivo TituloArchivo= new EscribirArchivo();
        String Titulo="Partida Versus "+fecha.format(LocalDateTime.now());
        TituloArchivo.EscribirLog(Titulo, Titulo);
        batRonda=new Batalla();
        
        for (int i = 0; i < 12; i++) {
            var ganadorrond=-1;
            String GanadorImpre="";
            BonificacionesTerreno(CampoElegido);
            //el metodo BatallaRonda devuelve el numero de la posicion del ganador de la partida
            ganadorrond= batRonda.BatallaRonda(partida[0].getEquipo(), partida[1].getEquipo(), ronda, Titulo);
            //ver ganador
            if (ganadorrond<2) {
                GanadorImpre="\nEl Ganador es "+partida[ganadorrond].getNombre()+"\n\n\n";
                System.out.println(GanadorImpre);
            }else{
                GanadorImpre="\nEl Ganador es empate\n\n\n";
                System.out.println(GanadorImpre);
                i--;
            }
            TituloArchivo.EscribirLog(GanadorImpre, Titulo);
            for (int j = 0; j < 2; j++) {
                partida[j].Restaurar();
                //menu de turno Jugador
                partida[j].ReestblecerOro();
                MenuTurno nuevaCompra=new MenuTurno(partida[j], ronda);
            }
            
            ronda++;
            //reducir vida del Jugador si pierde la partida
            if (ganadorrond==1) {
                if (i==1 || i==2 || i==3) {
                    partida[0].setVida(partida[0].getVida()-1);
                }else if (i==4 || i==5 || i==6) {
                    partida[0].setVida(partida[0].getVida()-2);
                }else{
                    partida[0].setVida(partida[0].getVida()-3);
                }
                //aumentar la Cantidad de partidas ganadas Ganados
                ganadosjug2++;
            }else if(ganadorrond==0){
                if (i==1 || i==2 || i==3) {
                    partida[1].setVida(partida[1].getVida()-1);
                }else if (i==4 || i==5 || i==6) {
                    partida[1].setVida(partida[1].getVida()-2);
                }else{
                    partida[1].setVida(partida[1].getVida()-3);
                }
                //aumentar la Cantidad de partidas ganadas Ganados
                ganadosjug1++;
            }
            if (partida[0].getVida()<=0 || ganadosjug2==10 || ganadosjug1==10 || partida[1].getVida()<=0) i=12;
        }
    }
    public void BonificacionesTerreno(String CampoJuego){
        if (CampoJuego.equalsIgnoreCase("pantano")) {
            terreno= new Pantano();
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "reptil");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "reptil"));
            }
        }else if (CampoJuego.equalsIgnoreCase("Nubes")) {
            terreno= new Nubes();
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "volador");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "volador"));
            }
        }else if (CampoJuego.equalsIgnoreCase("Mar") ){
            terreno= new Mar();
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "acuatico");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "acuatico"));
            }
        }else if (CampoJuego.equalsIgnoreCase("bosque")) {
            terreno= new Bosque();
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "Terrestre");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "Terrestre"));
            }
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "Mamifero");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "Mamifero"));
            }
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "solitario");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "solitario"));
            }
        }else{
            terreno=null;
        }
    
    }
}
