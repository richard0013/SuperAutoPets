
package Inicio;

import CamposJuego.*;
import Otros.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Arena {
    private Jugador[] partida = new Jugador[2];
    private int ronda;
    private Campos terreno;

    public Arena() {
        ronda=1;
        IniciarPartica();
    }
    
    public void IniciarPartica(){
        partida[0]= new Jugador();
        partida[1]= new Jugador();
        partida[0].setNombre(IngresoTexto.Leer("\n\n\nIngrese nombre para el Jugador"));
        MenuTurno nuevaCompra=new MenuTurno(partida[1], 1,1);
        partida[1]=nuevaCompra.getComprador();
        partida[1].setNombre("BOT");
        nuevaCompra=new MenuTurno(partida[0], 1);
        partida[0]=nuevaCompra.getComprador();
        elegirCampo();
    }
    
    public void elegirCampo(){
        int opcion;
        String respuesta=IngresoTexto.Leer("\n\nEliga Mapa para Jugar \nOpcion 1: Pantano \nOpcion 2: Nubes"
                + "\nOpcion 3: Mar \nOpcion 4: Bosque \nOpcion 5: Granja"
                +"\nOpcion 6: Sin Campo \nOpcion 7: Sabana \nEliga la opcion del mapa en el que desea jugar");
        opcion=Integer.parseInt(respuesta);
        switch(opcion){
            case 1: 
                batallaEquipos("pantano");
                break;
            case 2: 
                batallaEquipos("nubes");
                break;
            case 3: 
                batallaEquipos("Mar");
                break;
            case 4: 
                batallaEquipos("Bosque");
                break;
            case 5: 
                batallaEquipos("Granja");
                break;
            case 6: 
                batallaEquipos("Sin Campo");
                break;
            case 7: 
                batallaEquipos("Sabana");
                break;
            default : 
                elegirCampo();
                break;
        }
    }
    
    public void batallaEquipos(String CampoElegido){
        int ganados=0;
        Batalla batRonda= null;
        //para el registro de tiempo de las batallas 
        DateTimeFormatter fecha = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        EscribirArchivo TituloArchivo= new EscribirArchivo();
        String Titulo="Partida en Arena "+fecha.format(LocalDateTime.now());
        TituloArchivo.EscribirLog(Titulo, Titulo);
        
            batRonda=new Batalla();
        for (int i = 0; i < 12; i++) {
            var ganadorrond=-1;
            String GanadorImpre="";
            BonificacionesTerreno(CampoElegido);
            //el metodo BatallaRonda devuelve el numero de la posicion del ganador de la partida
            ganadorrond= batRonda.BatallaRonda(partida[0].getEquipo(), partida[1].getEquipo(), ronda, Titulo);
            //ver ganador
            if (ganadorrond<2) {
                GanadorImpre="\nEl Ganador es "+partida[ganadorrond].getNombre()+"\n\n\n";
                System.out.println(GanadorImpre);
            }else{
                GanadorImpre="\nEl Ganador es empate\n\n\n";
                System.out.println(GanadorImpre);
                i--;
            }
            TituloArchivo.EscribirLog(GanadorImpre, Titulo);
            partida[0].Restaurar();
            ronda++;
            //menu de turno Jugador
            partida[0].ReestblecerOro();
            
            MenuTurno nuevaCompra=new MenuTurno(partida[0], ronda);
            //cambiar las Mascotas del bot
            nuevaCompra=new MenuTurno(partida[1], ronda, 1);
            partida[1].setEquipo(nuevaCompra.getComprador().getEquipo());
            //reducir vida del Jugador si pierde la partida
            if (ganadorrond==1) {
                if (i==1 || i==2 || i==3) {
                    partida[0].setVida(partida[0].getVida()-1);
                }else if (i==4 || i==5 || i==6) {
                    partida[0].setVida(partida[0].getVida()-2);
                }else{
                    partida[0].setVida(partida[0].getVida()-3);
                }
            }else{
                //aumentar la Cantidad de partidas ganadas Ganados
                ganados++;
            }
            if (partida[0].getVida()<=0 || ganados==10) i=12;
        }
    }
    public void BonificacionesTerreno(String CampoJuego){
        if (CampoJuego.equalsIgnoreCase("pantano")) {
            terreno= new Pantano();
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "reptil");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "reptil"));
            }
        }else if (CampoJuego.equalsIgnoreCase("Nubes")) {
            terreno= new Nubes();
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "volador");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "volador"));
            }
        }else if (CampoJuego.equalsIgnoreCase("Mar") ){
            terreno= new Mar();
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "acuatico");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "acuatico"));
            }
        }else if (CampoJuego.equalsIgnoreCase("bosque")) {
            terreno= new Bosque();
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "Terrestre");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "Terrestre"));
            }
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "Mamifero");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "Mamifero"));
            }
            terreno.ContadorRestiles(partida[0].getEquipo(), partida[1].getEquipo(), "solitario");
            for (int i = 0; i < 2; i++) {
                partida[i].setEquipo(terreno.Bonificacion(partida[i].getEquipo(), "solitario"));
            }
        }else{
            terreno=null;
        }
    
    }
}
