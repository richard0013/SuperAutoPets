
package CamposJuego;

import Mascota.Mascota;
import java.util.StringTokenizer;


public class Nubes extends Campos{

    public Nubes() {
        this.nombre="nubes";
        this.tipo="volador";
        reptiles=0;
    }

    @Override
    public Mascota[] Bonificacion(Mascota[] equipo, String tipo) {
        Mascota arreglo[]=equipo;
        for (int i = 0; i < 3; i++) {
            StringTokenizer tiposMascota= new StringTokenizer(arreglo[i].getTipo(), "/");
            String[] tipos = new String[tiposMascota.countTokens()];
            for (int j = 0; j < tipos.length; j++) {
                tipos[j]=tiposMascota.nextToken();
                if (tipos[j].equalsIgnoreCase(tipo)) {
                    arreglo[i].setVida(arreglo[i].getVida()+(reptiles));
                    arreglo[i].setBonoVida(arreglo[i].getBonoVida()+reptiles);
                    arreglo[i].setDaño(arreglo[i].getVida()+(reptiles));
                    arreglo[i].setBonodaño(arreglo[i].getBonodaño()+reptiles);
                    System.out.println("Bonificacion Mascotas tipo Volador");
                }
            }
        }
        return arreglo;
    }
    
}
