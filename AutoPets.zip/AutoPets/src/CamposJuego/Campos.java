
package CamposJuego;

import Mascota.Mascota;
import java.util.StringTokenizer;


public class Campos {
    protected String nombre;
    protected String tipo;
    protected int reptiles;

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }
    
    public Mascota[] Bonificacion(Mascota[] equipo, String tipo){
        return null;
    }
    
    
    public void ContadorRestiles(Mascota[] equipo1, Mascota[] equipo2, String buscar){
        reptiles=0;
        for (int i = 0; i < 3; i++) {
            StringTokenizer tiposMascota= new StringTokenizer(equipo1[i].getTipo(), "/");
            String[] tipos = new String[tiposMascota.countTokens()];
            for (int j = 0; j < tipos.length; j++) {
                tipos[j]=tiposMascota.nextToken();
                if (tipos[j].equalsIgnoreCase(buscar)) reptiles++;
            }
            tiposMascota= new StringTokenizer(equipo2[i].getTipo(), "/");
            tipos = new String[tiposMascota.countTokens()];
            for (int j = 0; j < tipos.length; j++) {
                tipos[j]=tiposMascota.nextToken();
                if (tipos[j].equalsIgnoreCase(buscar)) reptiles++;
            }
        }
    }
    
}
