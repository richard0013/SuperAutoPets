
package CamposJuego;

import Mascota.Mascota;
import java.util.StringTokenizer;


public class Bosque extends Campos{

    public Bosque() {
        this.nombre="Mar";
        this.tipo="acuatico";
        reptiles=0;
    }
    
    @Override
    public Mascota[] Bonificacion(Mascota[] equipo, String tipo) {
            Mascota arreglo[]=equipo;
        for (int i = 0; i < 3; i++) {
            StringTokenizer tiposMascota= new StringTokenizer(arreglo[i].getTipo(), "/");
            String[] tipos = new String[tiposMascota.countTokens()];
            for (int j = 0; j < tipos.length; j++) {
                tipos[j]=tiposMascota.nextToken();
                if (tipos[j].equalsIgnoreCase(tipo) && tipo.equalsIgnoreCase("terrestre")) {
                    arreglo[i].setDaño(arreglo[i].getDaño()+(reptiles*2));
                    arreglo[i].setBonodaño(arreglo[i].getBonodaño()+(reptiles*2));
                    System.out.println("Bonificacion Mascotas tipo Terrestre");
                }else if (tipos[j].equalsIgnoreCase(tipo) && tipo.equalsIgnoreCase("mamifero")) {
                    arreglo[i].setVida(arreglo[i].getVida()+(reptiles*2));
                    arreglo[i].setBonoVida(arreglo[i].getBonoVida()+(reptiles*2));
                    System.out.println("Bonificacion Mascotas tipo Mamifero");
                }else if (tipos[j].equalsIgnoreCase(tipo) && tipo.equalsIgnoreCase("solitario")) {
                    arreglo[i].setDaño(arreglo[i].getDaño()-(arreglo[i].getDaño()*0.2));
                    arreglo[i].setBonodaño(arreglo[i].getBonodaño()+(arreglo[i].getDaño()*0.2));
                    System.out.println("Nerfeo a mascotas tipo Solitario");
                }
            }
        }
        return arreglo;
    }
    
}
