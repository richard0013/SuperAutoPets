

package Mascota;


public class Conejo   extends Mascota {
    public Conejo   () {
        //tier 3
        this.Nombre="Conejo";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero";
        //asignarle cantidad de vida inicial
        this.vida=2;
        //asignar cantidad de daño inicial
        this.daño=3;
        this.Habilidades="Cariño";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=2+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=3+bonodaño;
    }
}

