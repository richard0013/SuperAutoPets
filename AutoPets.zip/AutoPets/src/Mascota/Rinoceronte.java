

package Mascota;


public class Rinoceronte  extends Mascota {
    public Rinoceronte () {
        //tier 5
        this.Nombre="Rinoceronte";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="desertico/terrestre";
        //asignarle cantidad de vida inicial
        this.vida=8;
        //asignar cantidad de daño inicial
        this.daño=5;
        this.Habilidades="Estampida";

    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=8+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=5+bonodaño;
    }
}

