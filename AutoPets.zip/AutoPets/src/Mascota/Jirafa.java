

package Mascota;


public class Jirafa   extends Mascota {
    public Jirafa   () {
        //tier 3
        this.Nombre="Jirafa";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero/terrestre";
        //asignarle cantidad de vida inicial
        this.vida=5;
        //asignar cantidad de daño inicial
        this.daño=2;
        this.Habilidades="Fortaleza Aliada";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }

    @Override
    public void valoresIniciales() {
        this.vida=5+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=2+bonodaño;
    }
    
}

