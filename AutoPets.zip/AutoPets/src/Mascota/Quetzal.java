

package Mascota;


public class Quetzal  extends Mascota {
    public Quetzal () {
        //tier 7
        this.Nombre="Quetzal";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero/solitario";
        //asignarle cantidad de vida inicial
        this.vida=10;
        //asignar cantidad de daño inicial
        this.daño=10;
        this.Habilidades="Agregar";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=10+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=10+bonodaño;
    }
}

