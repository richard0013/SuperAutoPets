

package Mascota;


public class Hipopotamo  extends Mascota {
    public Hipopotamo () {
        //tier 4
        this.Nombre="Hipopotamo";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="acuático/terrestre";
        //asignarle cantidad de vida inicial
        this.vida=7;
        //asignar cantidad de daño inicial
        this.daño=4;
        this.Habilidades="Robustez";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=7+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=4+bonodaño;
    }
}

