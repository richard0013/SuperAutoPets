

package Mascota;


public class Leopardo  extends Mascota {
    public Leopardo () {
        //tier 6
        this.Nombre="Leopardo";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero/terrestre";
        //asignarle cantidad de vida inicial
        this.vida=4;
        //asignar cantidad de daño inicial
        this.daño=10;
        this.Habilidades="Zarpaso";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=4+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=10+bonodaño;
    }

}

