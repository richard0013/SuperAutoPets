

package Mascota;


public class Oveja  extends Mascota {
    public Oveja  () {
        //tier 3
        this.Nombre="Oveja";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="domestico/terrestre";
        //asignarle cantidad de vida inicial
        this.vida=2;
        //asignar cantidad de daño inicial
        this.daño=2;
        this.Habilidades="Revolucion";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=2+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=2+bonodaño;
    }
}

