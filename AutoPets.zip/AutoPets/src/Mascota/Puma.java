

package Mascota;


public class Puma  extends Mascota {
    public Puma () {
        //tier 4
        this.Nombre="Puma";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero/terrestre";
        //asignarle cantidad de vida inicial
        this.vida=7;
        //asignar cantidad de daño inicial
        this.daño=3;
        this.Habilidades="Sigilo";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=7+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=3+bonodaño;
    }

}

