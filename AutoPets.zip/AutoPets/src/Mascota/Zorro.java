
package Mascota;


public class Zorro extends Mascota {
    public Zorro () {
        //tier 2
        this.Nombre="Zorro";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="solitario/terrestre";
        //asignarle cantidad de vida inicial
        this.vida=2;
        //asignar cantidad de daño inicial
        this.daño=5;
        this.Habilidades="Ataque Rapido";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }

    @Override
    public void valoresIniciales() {
        this.vida=2+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=5+bonodaño;
    }
    

}
