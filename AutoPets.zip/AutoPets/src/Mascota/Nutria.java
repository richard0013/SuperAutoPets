
package Mascota;


public class Nutria extends Mascota {
    public Nutria () {
        //tier 1
        this.Nombre="Nutria";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero";
        //asignarle cantidad de vida inicial
        this.vida=2;
        //asignar cantidad de daño inicial
        this.daño=1;
        this.Habilidades="Ventaja Economica";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    
    }

    @Override
    public void valoresIniciales() {
        this.vida=2+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=1+bonodaño;
    }
    
}