
package Mascota;


public class Camello extends Mascota {
    public Camello () {
        //tier 3
        this.Nombre="Camello";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero/desertico";
        //asignarle cantidad de vida inicial
        this.vida=5;
        //asignar cantidad de daño inicial
        this.daño=2;
        this.Habilidades="Joroba";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=5+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=2+bonodaño;
    }
}
