

package Mascota;


public class Llama  extends Mascota {
    public Llama () {
        //tier 4
        this.Nombre="Llama";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="terrestra";
        //asignarle cantidad de vida inicial
        this.vida=6;
        //asignar cantidad de daño inicial
        this.daño=3;
        this.Habilidades="Frotaleza Individual";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=6+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=3+bonodaño;
    }
}

