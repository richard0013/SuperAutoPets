

package Mascota;


public class Panda  extends Mascota {
    public Panda () {
        //tier 6
        this.Nombre="Panda";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero/solitario";
        //asignarle cantidad de vida inicial
        this.vida=5;
        //asignar cantidad de daño inicial
        this.daño=5;
        this.Habilidades="Fortaleza";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=5+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=5+bonodaño;
    }
}

