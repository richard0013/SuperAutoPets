

package Mascota;


public class Lobo   extends Mascota {
    public Lobo   () {
        //tier 3
        this.Nombre="Lobo";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="solitario/terrestre";
        //asignarle cantidad de vida inicial
        this.vida=4;
        //asignar cantidad de daño inicial
        this.daño=3;
        this.Habilidades="Aullido";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=4+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=3+bonodaño;
    }
}

