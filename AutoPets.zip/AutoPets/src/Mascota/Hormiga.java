/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mascota;

/**
 *
 * @author david
 */
public class Hormiga extends Mascota{

    public Hormiga() {
        this.Nombre="Hormiga";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="insecto/terrestre";
        //asignarle cantidad de vida inicial
        this.vida=2;
        //asignar cantidad de daño inicial
        this.daño=1;
        this.Habilidades= "Compañerismo";
    }

    @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        int aliado= (int)(Math.random()*3);
        int bono= (int)(Math.random()*3);
        if (bono==0) {
            equipo[aliado].setVida(equipo[aliado].getVida()+1);
            equipo[aliado].setDaño(equipo[aliado].getDaño()+2);
        }else if(bono==1){
            equipo[aliado].setVida(equipo[aliado].getVida()+2);
            equipo[aliado].setDaño(equipo[aliado].getDaño()+4);
        }else{
            equipo[aliado].setVida(equipo[aliado].getVida()+3);
            equipo[aliado].setDaño(equipo[aliado].getDaño()+6);
        }
        
        return equipo;
    }

    @Override
    public void valoresIniciales() {
        this.vida=2+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=1+bonodaño;
    }
    
}
