
package Mascota;


public class Rata extends Mascota {
    public Rata () {
        //tier 2
        this.Nombre="Rata";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="terrestre/solitario";
        //asignarle cantidad de vida inicial
        this.vida=5;
        //asignar cantidad de daño inicial
        this.daño=4;
        this.Habilidades="Aqyuda hipocrita";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }

    @Override
    public void valoresIniciales() {
        this.vida=5+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=4+bonodaño;
    }

    
}
