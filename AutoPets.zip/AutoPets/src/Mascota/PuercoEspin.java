
package Mascota;


public class PuercoEspin extends Mascota {
    public PuercoEspin () {
        //tier 2
        this.Nombre="Puerco Espin";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="solitario/terrestre";
        //asignarle cantidad de vida inicial
        this.vida=2;
        //asignar cantidad de daño inicial
        this.daño=3;
        this.Habilidades="Espinas Salvages";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }

    @Override
    public void valoresIniciales() {
        this.vida=2+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=3+bonodaño;
    }
    

}
