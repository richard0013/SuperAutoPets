

package Mascota;


public class Camaleon  extends Mascota {
    public Camaleon () {
        //tier 7
        this.Nombre="Camaleon";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="reptil/solitario";
        //asignarle cantidad de vida inicial
        this.vida=8;
        //asignar cantidad de daño inicial
        this.daño=8;
        this.Habilidades="Copia La vida";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=8+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=8+bonodaño;
    }
}

