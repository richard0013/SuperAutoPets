

package Mascota;


public class Mamut  extends Mascota {
    public Mamut () {
        //tier 6
        this.Nombre="Mamut";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero/solitario";
        //asignarle cantidad de vida inicial
        this.vida=10;
        //asignar cantidad de daño inicial
        this.daño=3;
        this.Habilidades="Fuerza Compañeros";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=10+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=3+bonodaño;
    }
}

