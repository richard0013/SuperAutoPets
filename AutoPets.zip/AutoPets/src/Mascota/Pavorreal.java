
package Mascota;


public class Pavorreal extends Mascota {
    public Pavorreal () {
        //tier 2
        this.Nombre="Pavo Real";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="domestico/volador";
        //asignarle cantidad de vida inicial
        this.vida=5;
        //asignar cantidad de daño inicial
        this.daño=3;
        this.Habilidades="Potenciacion";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }

    @Override
    public void valoresIniciales() {
        this.vida=5+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=3+bonodaño;
    }
    
}
