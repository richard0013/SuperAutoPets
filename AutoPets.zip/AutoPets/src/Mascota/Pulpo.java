

package Mascota;


public class Pulpo  extends Mascota {
    public Pulpo () {
        //tier 6
        this.Nombre="Pulpo";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="acuatico/solitario";
        //asignarle cantidad de vida inicial
        this.vida=8;
        //asignar cantidad de daño inicial
        this.daño=8;
       this.Habilidades="Subir de Nivel";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=8+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=8+bonodaño;
    }
}

