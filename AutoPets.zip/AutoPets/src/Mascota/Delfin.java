

package Mascota;


public class Delfin  extends Mascota {
    public Delfin () {
        //tier 4
        this.Nombre="Delfin";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="acuático";
        //asignarle cantidad de vida inicial
        this.vida=6;
        //asignar cantidad de daño inicial
        this.daño=4;
        this.Habilidades="Salpicon";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=6+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=4+bonodaño;
    }
}

