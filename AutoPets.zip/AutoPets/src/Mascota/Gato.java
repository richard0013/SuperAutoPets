

package Mascota;


public class Gato  extends Mascota {
    public Gato () {
        //tier 6
        this.Nombre="Gato";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero/solitario";
        //asignarle cantidad de vida inicial
        this.vida=5;
        //asignar cantidad de daño inicial
        this.daño=4;
        this.Habilidades="Maullido";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=5+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=4+bonodaño;
    }
}

