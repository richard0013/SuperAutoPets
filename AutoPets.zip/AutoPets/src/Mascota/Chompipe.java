

package Mascota;


public class Chompipe  extends Mascota {
    public Chompipe () {
        //tier 5
        this.Nombre="Chompipe";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="terrestre/volador";
        //asignarle cantidad de vida inicial
        this.vida=4;
        //asignar cantidad de daño inicial
        this.daño=3;
        this.Habilidades="Solidaridad";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=4+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=3+bonodaño;
    }
}

