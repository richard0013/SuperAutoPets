/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mascota;

/**
 *
 * @author david
 */
public class Mascota {
    protected String Nombre;
    protected double daño;
    protected double vida;
    protected String efecto;
    protected String Habilidades;
    protected int Experiencia;
    protected String tipo;
    protected boolean vivo;
    protected int precio;
    protected int nivel;
    protected double bonoVida;
    protected double bonodaño;

    public Mascota() {
        vivo=true;
        
    }
    public void valoresIniciales(){
    }
    
    public void DefinirPrecio(){
        this.precio = 3;
    }

    public String getTipo() {
        return tipo;
    }

    public double getDaño() {
        return daño;
    }

    public void setDaño(double daño) {
        this.daño = daño;
    }

    public double getVida() {
        return vida;
    }

    public void setVida(double vida) {
        this.vida = vida;
        if (vida==0) {
            vivo=false;
        }
    }
    
    public Mascota[] BonificacionMascota(Mascota[] arreglo){
        return null;
    }
    
    public void Informacion(int valor){
        System.out.println("Macota: "+Nombre+"\n\tHabilidad: "+Habilidades+"\n\tTipo: "+tipo+"\n\tNivel: "+(nivel+1));
        if (valor==0) {
            System.out.println("\tPrecio: "+precio+" Monedas");
        }
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getNombre() {
        return Nombre;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public void Evolucion() {
        this.vida=vida+1;
        this.daño=+1;
        System.out.println(Nombre+" ha evolucionado a nivel "+(nivel+1));
    }

    public double getBonoVida() {
        return bonoVida;
    }

    public void setBonoVida(double bonoVida) {
        this.bonoVida = bonoVida;
    }

    public double getBonodaño() {
        return bonodaño;
    }

    public void setBonodaño(double bonodaño) {
        this.bonodaño = bonodaño;
    }
    
    
    
}
