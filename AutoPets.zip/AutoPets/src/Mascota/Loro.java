

package Mascota;


public class Loro extends Mascota {
    public Loro () {
        //tier 4
        this.Nombre="Loro";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="volador";
        //asignarle cantidad de vida inicial
        this.vida=5;
        //asignar cantidad de daño inicial
        this.daño=3;
        this.Habilidades="Copia";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=5+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=3+bonodaño;
    }
}

