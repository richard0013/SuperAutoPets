
package Mascota;


public class Caballo extends Mascota{
    public Caballo () {
        //tier 1
        this.Nombre="Caballo";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="mamifero/doméstico";
        //asignarle cantidad de vida inicial
        this.vida=1;
        //asignar cantidad de daño inicial
        this.daño=2;
        this.Habilidades="Rugido Aliado";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }

    @Override
    public void valoresIniciales() {
        this.vida=1+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=2+bonodaño;
    }
    
}