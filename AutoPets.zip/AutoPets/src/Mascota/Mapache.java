

package Mascota;


public class Mapache  extends Mascota {
    public Mapache  () {
        //tier 3
        this.Nombre="Mapache ";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="solitario";
        //asignarle cantidad de vida inicial
        this.vida=4;
        //asignar cantidad de daño inicial
        this.daño=5;
        this.Habilidades=" Repartir Poder";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }

    @Override
    public void valoresIniciales() {
        this.vida=4+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=5+bonodaño;
    }
    
}

