

package Mascota;


public class Cocodrilo  extends Mascota {
    public Cocodrilo () {
        //tier 5
        this.Nombre="Cocodrilo";
        //si tiene mas de 1 tipo separar cada tipo con /
        this.tipo="reptil/solitario";
        //asignarle cantidad de vida inicial
        this.vida=4;
        //asignar cantidad de daño inicial
        this.daño=8;
        this.Habilidades="Mordida";
    }
       @Override
    public Mascota[] BonificacionMascota(Mascota[] arreglo) {
        Mascota[] equipo= arreglo;
        
        return equipo;
    }
    @Override
    public void valoresIniciales() {
        this.vida=4+bonoVida;
        //asignar cantidad de daño inicial
        this.daño=8+bonodaño;
    }
}

