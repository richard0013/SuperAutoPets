
package Otros;

import Mascota.*;
import java.util.StringTokenizer;



public class MenuTurno {
    Jugador comprador;
    int ronda;
    Mascota[] arregloTienda;
    ArmarArreglo enTienda= new ArmarArreglo();
    int limiteAnimales=0;
    
    public MenuTurno(Jugador Compra, int ronda) {
        comprador=Compra;
        this.ronda=ronda;
        DefinirLimiteMascotas();
        arregloTienda=enTienda.Arreglo(limiteAnimales, ronda);
        Menu();
    }
    public MenuTurno(Jugador Compra, int ronda, int IA) {
        comprador=Compra;
        this.ronda=ronda;
        DefinirLimiteMascotas();
        arregloTienda=enTienda.Arreglo(limiteAnimales, ronda);
        TiendaMascotasIA();
    }
    
    public void Menu(){
        DefinirLimiteMascotas();
        int salir=-1;
        while(salir==-1){
            String respuesta=IngresoTexto.Leer("\n\n------------------Menu Turno------------------\n"
                    + "Jugador:"+comprador.getNombre()+"---------------Oro actual:"+comprador.getOro()+" Monedas"
                    + " \n\nOpcion 1: Comprar Mascotas \nOpcion 2: Comprar Comida"
                    + "\nOpcion 3: Ordenar Mascotas \nOpcion 4: Fusionar Mascotas \nOpcion 5: Vender Mascotas"
                    +"\nOpcion 6: Terminar turno \nEliga la opcion");
            int opcion=Integer.parseInt(respuesta);
            switch(opcion){
                case 1: 
                    TiendaMascotas(); 
                    break;
                case 2: break;
                case 3:
                    OrdenarMascotas ordena = new OrdenarMascotas();
                    comprador.setEquipo(ordena.Ordenar(comprador.getEquipo(), comprador.getContadorMascotas()));
                    break;
                case 4: 
                    Fusion(comprador.getEquipo());
                    break;
                case 5: 
                    if (comprador.getContadorMascotas()>0) {
                        OrdenarMascotas elimina = new OrdenarMascotas();
                        comprador.setEquipo(elimina.Vender(comprador.getEquipo(), comprador.getContadorMascotas()));
                        comprador.setOro(3);
                        comprador.setContadorMascotas(-1);
                    }
                    break;
                case 6: 
                    if (comprador.getContadorMascotas()>=limiteAnimales) {
                        salir=0;
                    }else{
                        System.out.println("Debe de Tener al menos "+limiteAnimales+" mascotas para continuar la partida");
                    }
                    break;
            }
        }
    }
    
    public void TiendaMascotas(){
        
        int limiteTier=0;
        boolean salir=false;
        
        while (salir==false) {
            System.out.println("Jugador:"+comprador.getNombre()+"---------------Oro actual:"+comprador.getOro()+" Monedas");
            for (int i = 0; i < limiteAnimales; i++) {
                System.out.println("Opcion "+(i+1)+":");
                arregloTienda[i].Informacion(0);
            }
            String respuesta=IngresoTexto.Leer("Opcion "+(limiteAnimales+1)+": Salir \n\n Eliga Opcion" );
            int opc=Integer.parseInt(respuesta);
            if (opc<=limiteAnimales) {
                if (comprador.getOro()>=arregloTienda[opc-1].getPrecio()) {
                    comprador.insertarMascota(comprador.getContadorMascotas(), arregloTienda[opc-1]);
                    comprador.setOro(-1*arregloTienda[opc-1].getPrecio());
                    System.out.println("\n\n---------------COMPRA REALIZADA CON EXITO--------------------\n\n");
                }else{
                    System.out.println("No tiene Oro suficiente para la compra");
                }
            }else if(opc==(limiteAnimales+1)){
                salir=true;
            }
        }
    }

    public Jugador getComprador() {
        return comprador;
    }
    
     public void TiendaMascotasIA(){
        int limiteAnimales=0;
        int limiteTier=0;
        boolean salir=false;
        ArmarArreglo enTienda= new ArmarArreglo(); 
        if (ronda ==1 || ronda ==2 || ronda ==3) {
            limiteAnimales=3;
        }else if(ronda ==4 || ronda ==5 || ronda ==6){
            limiteAnimales=4;
        }else if(ronda >=7){
            limiteAnimales=5;
        }
        arregloTienda=enTienda.Arreglo(limiteAnimales, ronda);
        for (int i = 0; i < limiteAnimales; i++) {
            comprador.insertarMascota(i, arregloTienda[i]);
        }
    }
     public void DefinirLimiteMascotas(){
        if (ronda ==1 || ronda ==2 || ronda ==3) {
            limiteAnimales=3;
        }else if(ronda ==4 || ronda ==5 || ronda ==6){
            limiteAnimales=4;
        }else if(ronda >=7){
            limiteAnimales=5;
        } 
     }
     
     public void Fusion(Mascota[] equip){
         for (int i = 0; i < comprador.getContadorMascotas(); i++) {
             System.out.println("Opcion "+(i+1));
             equip[i].Informacion(1);
         }
         String respuesta=IngresoTexto.Leer("Ingrese las opciones de las mascotas que desea fusionar ejemplo(1,2)");
         StringTokenizer separar= new StringTokenizer(respuesta, ",");
         int pos1=Integer.parseInt(separar.nextToken())-1;
         int pos2=Integer.parseInt(separar.nextToken())-1;
         if (equip[pos1].getNombre().equals(equip[pos2].getNombre())) {
             if (equip[pos1].getNivel()<3) {
                 equip[pos1].Evolucion();
                 equip[pos1].setNivel(equip[pos1].getNivel()+1);
                 if (pos2<(comprador.getContadorMascotas()-1)) {
                     for (int i = pos2; i < comprador.getContadorMascotas(); i++) {
                         equip[i]=equip[i+1];
                     }
                 }else{
                     equip[pos2]=null;
                 }
                 comprador.setContadorMascotas((-1));
             }
         }else{
             System.out.println("No es posible Fusionar a dos animales distintos");
         }
     }
    
}
