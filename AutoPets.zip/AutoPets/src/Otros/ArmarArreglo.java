
package Otros;

import Mascota.*;



public class ArmarArreglo {

    public ArmarArreglo() {
    }
    
    public Mascota[] Arreglo(int limite, int ronda){
        Mascota[] arreglo= new Mascota[limite];
        int repetidos[] = new int[limite];
        boolean salir=false;
        int grupo=0;
        int empieza=1;
        int j=0;
        for (int i = 0; i < limite; i++) {
            repetidos[i]=0;
        }
        if (ronda==1) {
            grupo=8;
        }else if (ronda==2 || ronda==3) {
            grupo=8;
            empieza=9;
        }else if (ronda==4 || ronda==5) {
            grupo=11;
            empieza=17;
        }else if (ronda==6 || ronda==7) {
            grupo=8;
            empieza=28;
        }else if (ronda==8 || ronda==9) {
            grupo=8;
            empieza=36;
        }else if (ronda==10 || ronda==11) {
            grupo=9;
            empieza=44;
        }else if (ronda==12) {
            grupo=6;
            empieza=49;
        }
        while (salir==false) {            
            boolean repetido=false;
            int numeroAleatorio = (int)(Math.random()*grupo)+empieza;
            for (int i = 0; i < limite; i++) {
                if (repetidos[i]==numeroAleatorio) {
                    repetido=true;
                }
            }
            if (repetido==false) {
                repetidos[j]=numeroAleatorio;
                arreglo[j]=Objeto(numeroAleatorio);
                arreglo[j].DefinirPrecio();
                j++;
            }
            if (j==limite) salir=true;
        }
        
        return arreglo;
    }
    public Mascota Objeto(int numero){
        Mascota Devolver=null;
        switch (numero) {
            case 1:
                Devolver= new Hormiga();
                break;
            case 2:
                Devolver= new Pescado();
                break;
            case 3:
                Devolver= new Mosquito();
                break;
            case 4:
                Devolver= new Grillo();
                break;
            case 5:
                Devolver= new Castor();
                break;
            case 6:
                Devolver= new Caballo();
                break;
            case 7:
                Devolver= new Nutria();
                break;
            case 8:
                Devolver= new Escarabajo();
                break;
            case 9:
                Devolver= new Sapo();
                break;
            case 10:
                Devolver= new Dodo();
                break;
            case 11:
                Devolver= new Elefante();
                break;
            case 12:
                Devolver= new PuercoEspin();
                break;
            case 13:
                Devolver= new Pavorreal();
                break;
            case 14:
                Devolver= new Rata();
                break;
            case 15:
                Devolver= new Zorro();
                break;
            case 16:
                Devolver= new Araña();
                break;
            case 17:
                Devolver= new Camello();
                break;
            case 18:
                Devolver= new Mapache();
                break;
            case 19:
                Devolver= new Jirafa();
                break;
            case 20:
                Devolver= new Tortuga();
                break;
            case 21:
                Devolver= new caracol();
                break;
            case 22:
                Devolver= new Oveja();
                break;
            case 23:
                Devolver= new Conejo();
                break;
            case 24:
                Devolver= new Lobo();
                break;
            case 25:
                Devolver= new Buey();
                break;
            case 26:
                Devolver= new Canguro();
                break;
            case 27:
                Devolver= new Buho();
                break;
            case 28:
                Devolver= new Venado();
                break;
            case 29:
                Devolver= new Loro();
                break;
            case 30:
                Devolver= new Hipopotamo();
                break;
            case 31:
                Devolver= new Delfin();
                break;
            case 32:
                Devolver= new Puma();
                break;
            case 33:
                Devolver= new Ballena();
                break;
            case 34:
                Devolver= new Ardilla();
                break;
            case 35:
                Devolver= new Llama();
                break;
            case 36:
                Devolver= new Foca();
                break;
            case 37:
                Devolver= new Jaguar();
                break;
            case 38:
                Devolver= new Escorpion();
                break;
            case 39:
                Devolver= new Rinoceronte();
                break;
            case 40:
                Devolver= new Mono();
                break;
            case 41:
                Devolver= new Cocodrilo();
                break;
            case 42:
                Devolver= new Vaca();
                break;
            case 43:
                Devolver= new Chompipe();
                break;
            case 44:
                Devolver= new Panda();
                break;
            case 45:
                Devolver= new Gato();
                break;
            case 46:
                Devolver= new Tigre();
                break;
            case 47:
                Devolver= new Serpiente();
                break;
            case 48:
                Devolver= new Mamut();
                break;
            case 49:
                Devolver= new Leopardo();
                break;
            case 50:
                Devolver= new Gorila();
                break;
            case 51:
                Devolver= new Pulpo();
                break;
            case 52:
                Devolver= new Mosca();
                break;
            case 53:
                Devolver= new Quetzal();
                break;
            case 54:
                Devolver= new Camaleon();
                break;
        }
    return Devolver;
    }
}
