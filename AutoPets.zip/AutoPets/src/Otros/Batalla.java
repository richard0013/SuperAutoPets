
package Otros;

import Mascota.Mascota;


public class Batalla {

    public Batalla() {
    }
    
    public int BatallaRonda(Mascota[] jug1, Mascota[] jug2, int Ronda, String titulo){
        String batalla;
        int i=1;
        int mascota1=0;
        int mascota2=0;
        int jugGana=-1;
        int limiteAnimales=0;
        //definir Cantidad de Batalas
        System.out.println("La ronda recibida es "+ Ronda);
        if (Ronda>=1 && Ronda<=3) {
            limiteAnimales=3;
        }else if (Ronda>=4 && Ronda<=6) {
            limiteAnimales=4;
        }else{
            limiteAnimales=5;
        }
        boolean ganador=false;
        
        while (ganador==false) {
            System.out.println("Limite animales "+limiteAnimales);
            System.out.println("posicion Mascota 1 "+ mascota1+" posicion Mascota 2 "+mascota2);
            double daño1=jug1[mascota1].getDaño();
            double daño2=jug2[mascota2].getDaño();
            jug1[mascota1].setVida(jug1[mascota1].getVida()-daño2);
            jug2[mascota2].setVida(jug2[mascota2].getVida()-daño1);
            batalla="---------------------------------------RONDA NUMERO "+(Ronda)+"---------------------------------------"
                    +"\n---------------------------------------Batalla Numero "+i+"---------------------------------------"+"\n\tBatalla entre "
                    +jug1[mascota1].getNombre()+" y "+jug2[mascota2].getNombre()+"\n\t"+jug1[mascota1].getNombre()+" realiza ataque de "
                    +jug1[mascota1].getDaño()+" puntos de daño y "+jug2[mascota2].getNombre()+" realiza ataque de "+jug2[mascota2].getDaño()+" puntos de daño\n\t"
                    +jug1[mascota1].getNombre()+ " tiene "+jug1[mascota1].getVida()+" puntos de vida y "+jug2[mascota2].getNombre()+" tiene "
                    +jug2[mascota2].getVida()+" puntos de vida";
            
            if (jug1[mascota1].getVida()<=0) mascota1++;
            if (jug2[mascota2].getVida()<=0) mascota2++;
            
            System.out.println(batalla);
            //contador de Batallas
            i++;
            if (mascota1>=limiteAnimales || mascota2>=limiteAnimales) ganador=true;
            if (mascota1>=limiteAnimales) jugGana=1;
            if (mascota2>=limiteAnimales) jugGana=0;
            if (mascota1>=limiteAnimales && mascota2>=limiteAnimales) jugGana=2;
            
            try {	
		Thread.sleep(500);	
            }catch(Exception e) {
                System.out.println(e);
            }
            EscribirArchivo a1 = new EscribirArchivo();
            a1.EscribirLog(batalla, titulo);
        }
        return jugGana;
    }
    
}


