
package Otros;

import Mascota.Mascota;


public class Jugador {
    private Mascota [] equipo;
    private String nombre;
    private int vida;
    private int oro;
    private int contadorMascotas;

    public Jugador() {
        vida=10;
        oro=10;
        equipo = new Mascota[25];
        contadorMascotas=0;
    }
    
    public void Restaurar(){
        for (int i = 0; i < contadorMascotas; i++) {
            equipo[i].valoresIniciales();
        }
    }
    
    public Mascota[] getEquipo() {
        return equipo;
    }

    public void setEquipo(Mascota[] equipo) {
        this.equipo = equipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getOro() {
        return oro;
    }

    public void setOro(int oror) {
        this.oro += oror;
    }

    public int getContadorMascotas() {
        return contadorMascotas;
    }

    public void setContadorMascotas(int sumrestMascotas) {
        contadorMascotas=contadorMascotas+sumrestMascotas;
    }
    
    public void insertarMascota(int posicion, Mascota insert){
        equipo[posicion]= insert;
        contadorMascotas++;
    }
    
    public void informaciondeMascota(){
        for (int i = 0; i < contadorMascotas; i++) {
            equipo[i].Informacion(1);
        }
    }
    public void ReestblecerOro(){
        oro=10;
    }
    public void Comprobarvidas(){
        for (int i = 0; i < contadorMascotas; i++) {
            System.out.println("la vida de la mascota "+equipo[i].getVida());
        }
    }
    public Mascota clonar(int posicion){
        Mascota a1 = equipo[posicion];
        return a1;
    }
    
}
