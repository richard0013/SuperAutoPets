
package Otros;
import Mascota.*;
import java.util.StringTokenizer;

public class OrdenarMascotas {

    public OrdenarMascotas() {
    }
    
    public Mascota[] Ordenar(Mascota[] equipo, int mascotas){
        Mascota[] OrdenarEquipo=equipo;
        Mascota[] temporal;
        //Primero se Imprime el orden actual de las mascotas
        for (int i = 0; i < mascotas; i++) {
            System.out.println("------------Mascota No "+(i+1)+"-------------");
            OrdenarEquipo[i].Informacion(1);
        }
        String nuevoOrden=IngresoTexto.Leer("Ingrese el nuevo orden de su mascotas separados por comas sin espacios ejemplo(3,1,2)");
        //eliminar las comas y deducier el nuevo orden
        StringTokenizer orden= new StringTokenizer(nuevoOrden, ",");
        String[] tipos = new String[orden.countTokens()];
        int[] newOrden = new int[orden.countTokens()];
        for (int i = 0; i < orden.countTokens(); i++) {
            tipos[i]=orden.nextToken();
            newOrden[i]=Integer.parseInt(tipos[i])-1;
        }
        temporal= new Mascota[newOrden.length];
        for (int i = 0; i < newOrden.length; i++) temporal[i]=OrdenarEquipo[newOrden[i]];
        for (int i = 0; i < newOrden.length; i++) OrdenarEquipo[i]=temporal[i];
        
        
        return OrdenarEquipo;
    }
    
    public Mascota[] Vender(Mascota[] equipo, int mascotas){
        Mascota[] OrdenarEquipo=equipo;
        Mascota[] temporal;
        //Primero se Imprime el orden actual de las mascotas
        for (int i = 0; i < mascotas; i++) {
            System.out.println("------------Mascota No "+(i+1)+"-------------");
            OrdenarEquipo[i].Informacion(1);
        }
        String nuevoOrden=IngresoTexto.Leer("Ingrese el numero de la mascota que desea Vender (ejemplo: 1)");
        //eliminar las comas y deducier el nuevo orden
        int posicion = Integer.parseInt(nuevoOrden);
        for (int i = 0; i < (mascotas-1); i++) {
            if (i>=posicion) {
                OrdenarEquipo[i]=OrdenarEquipo[i+1];
            }
        }
        return OrdenarEquipo;
    }
    
    
}
