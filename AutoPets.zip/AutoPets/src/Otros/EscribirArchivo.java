
package Otros;

import java.io.*;


public class EscribirArchivo {
    
    public void EscribirLog(String Linea, String titulo){
        try{
            File archivo= new File(titulo+".txt");
            System.out.println(titulo);
            FileWriter fichero = new FileWriter(archivo, true);

            fichero.write(Linea+"\n");
            fichero.close();

        } catch (Exception e) {
            System.out.println("algo fallo");
        }
    }
}
