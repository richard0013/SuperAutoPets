
package Otros;

import java.util.Scanner;


public class IngresoTexto {
    
    private static Scanner sc= new Scanner(System.in);
    
    public static String Leer(String Mensaje){
        String respuesta="";
        int salir=-1;
        while (salir==-1){
            System.out.println(Mensaje);
            respuesta=sc.nextLine();
            if (!respuesta.equals("")) {
                salir=0;
            }
        }
        return respuesta;
    }
}
